from sklearn.metrics import roc_auc_score
from sklearn.metrics import accuracy_score
import numpy as np
import pandas as pd


def getAUC(y_true, y_score):
    '''AUC metric.
    :param y_true: the ground truth labels, shape: (n_samples, n_classes) for multi-label, and (n_samples,) for other tasks
    :param y_score: the predicted score of each class, shape: (n_samples, n_classes)
    :param task: the task of current dataset

    '''
    # if task == 'binary-class':
    try:
        y_score = y_score[:, 1]
    except:
        y_score = y_score
    return roc_auc_score(y_true, y_score)
    # elif task == 'multi-label, binary-class':
    #     auc = 0
    #     for i in range(y_score.shape[1]):
    #         label_auc = roc_auc_score(y_true[:, i], y_score[:, i])
    #         print(label_auc)
    #         auc += label_auc
    #     return auc / y_score.shape[1]
    # else:
    #     auc = 0
    #     zero = np.zeros_like(y_true)
    #     one = np.ones_like(y_true)
    #     for i in range(y_score.shape[1]):
    #         y_true_binary = np.where(y_true == i, one, zero)
    #         y_score_binary = y_score[:, i]
    #         auc += roc_auc_score(y_true_binary, y_score_binary)
    #     return auc / y_score.shape[1]


def getACC(y_true, y_score,  threshold=0.5):
    '''Accuracy metric.
    :param y_true: the ground truth labels, shape: (n_samples, n_classes) for multi-label, and (n_samples,) for other tasks
    :param y_score: the predicted score of each class, shape: (n_samples, n_classes)
    :param task: the task of current dataset
    :param threshold: the threshold for multilabel and binary-class tasks

    '''
    # if task == 'multi-label, binary-class':
    #     zero = np.zeros_like(y_score)
    #     one = np.ones_like(y_score)
    #     y_pre = np.where(y_score < threshold, zero, one)
    #     acc = 0
    #     for label in range(y_true.shape[1]):
    #         label_acc = accuracy_score(y_true[:, label], y_pre[:, label])
    #         acc += label_acc
    #     return acc / y_true.shape[1]
    # elif task == 'binary-class':
    y_pre = np.zeros_like(y_true)
    for i in range(y_score.shape[0]):
        y_pre[i] = (y_score[i][-1] > threshold)
    return accuracy_score(y_true, y_pre)
    # else:
    #     y_pre = np.zeros_like(y_true)
    #     for i in range(y_score.shape[0]):
    #         y_pre[i] = np.argmax(y_score[i])
    #     return accuracy_score(y_true, y_pre)


def save(y_true, y_score, outputpath):
    '''Save ground truth and scores
    :param y_true: the ground truth labels, shape: (n_samples, n_classes) for multi-label, and (n_samples,) for other tasks
    :param y_score: the predicted score of each class, shape: (n_samples, n_classes)
    :param outputpath: path to save the result csv

    '''
    idx = []

    idx.append('id')

    for i in range(y_true.shape[1]):
        idx.append('true_%s' % (i))
    for i in range(y_score.shape[1]):
        idx.append('score_%s' % (i))

    df = pd.DataFrame(columns=idx)
    for id in range(y_score.shape[0]):
        dic = {}
        dic['id'] = id
        for i in range(y_true.shape[1]):
            dic['true_%s' % (i)] = y_true[id][i]
        for i in range(y_score.shape[1]):
            dic['score_%s' % (i)] = y_score[id][i]

        df_insert = pd.DataFrame(dic, index = [0])
        df = df.append(df_insert, ignore_index=True)

    df.to_csv(outputpath, sep=',', index=False, header=True, encoding="utf_8_sig")
